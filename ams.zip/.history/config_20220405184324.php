<?php
define('_AMSCODESECURITY', '16343942');
define('CURRENCY', '$');
define('WEB_URL', 'https://site.test/QLDC');
define('ROOT_PATH', 'D:\xampp\htdocs\Private\ams/');


define('DB_HOSTNAME', 'site.test');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_DATABASE', 'demo1_ams');
$link = new mysqli(DB_HOSTNAME,DB_USERNAME,DB_PASSWORD,DB_DATABASE);?>